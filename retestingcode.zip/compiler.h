
#ifndef tz_compiler_h
#define tz_compiler_h

#include "vm.h"

bool compile( const char* source, Chunk* chunk );

#endif
